<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/p', function () {
    return view('Portfolio');
});
use App\Http\Controllers\PortfolioController;

// Route::post('/personal-info', [PortfolioController::class, 'savePersonalInfo']);
// Route::post('/skills', [PortfolioController::class, 'saveSkills']);
// Route::post('/experiences', [PortfolioController::class, 'saveExperiences']);
// Route::post('/educations', [PortfolioController::class, 'saveEducations']);
// Route::post('/friends', [PortfolioController::class, 'saveFriends']);

// Route::post('/personal-info', [PortfolioController::class, 'savePersonalInfo']);


Route::get('/portfolio', [PortfolioController::class, 'index']);
Route::post('/personal-info', [PortfolioController::class, 'storePersonalInfo']);
Route::post('/skills', [PortfolioController::class, 'storeSkills']);
Route::post('/experience', [PortfolioController::class, 'storeExperience']);
Route::post('/education', [PortfolioController::class, 'storeEducation']);
Route::post('/friends', [PortfolioController::class, 'storeFriends']);
