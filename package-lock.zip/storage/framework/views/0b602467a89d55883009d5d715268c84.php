<!-- resources/views/Portfolio.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Portfolio Submission</h1>

        <!-- Personal Info Form -->
        <form action="<?php echo e(url('/personal-info')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2>Personal Info</h2>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="intro_heading">Intro Heading:</label>
                <input type="text" id="intro_heading" name="intro_heading" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="intro_detail">Intro Detail:</label>
                <textarea id="intro_detail" name="intro_detail" class="form-control" required></textarea>
            </div>
            <div class="form-group">
                <label for="cv">Upload CV:</label>
                <input type="file" id="cv" name="cv" class="form-control" accept=".pdf,.doc,.docx">
            </div>
            <button type="submit" class="btn btn-primary">Submit Personal Info</button>
        </form>

        <!-- Skills Form -->
        <form action="<?php echo e(url('/skills')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <h2>Skills</h2>
            <div id="skillsContainer">
                <div class="form-group">
                    <label for="skill_name">Skill Name:</label>
                    <input type="text" name="skills[0][name]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="skill_percentage">Skill Percentage:</label>
                    <input type="number" name="skills[0][percentage]" class="form-control" min="0" max="100" required>
                </div>
            </div>
            <button type="button" class="btn btn-secondary" onclick="addSkill()">Add More Skills</button>
            <button type="submit" class="btn btn-primary">Submit Skills</button>
        </form>

        <!-- Experience Form -->
        <form action="<?php echo e(url('/experience')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2>Experience</h2>
            <div id="experienceContainer">
                <div class="form-group">
                    <label for="experience_image">Add Image:</label>
                    <input type="file" name="experiences[0][image]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="experience_heading">Experience Heading:</label>
                    <input type="text" name="experiences[0][heading]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="experience_detail">Experience Detail:</label>
                    <textarea name="experiences[0][detail]" class="form-control" required></textarea>
                </div>
            </div>
            <button type="button" class="btn btn-secondary" onclick="addExperience()">Add More Experience</button>
            <button type="submit" class="btn btn-primary">Submit Experience</button>
        </form>

        <!-- Education Form -->
        <form action="<?php echo e(url('/education')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2>Education</h2>
            <div id="educationContainer">
                <div class="form-group">
                    <label for="education_image">Add Image:</label>
                    <input type="file" name="educations[0][image]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="education_detail">Education Detail:</label>
                    <input type="text" name="educations[0][detail]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="education_year_start">Start Year:</label>
                    <input type="text" name="educations[0][year_start]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="education_year_end">End Year:</label>
                    <input type="text" name="educations[0][year_end]" class="form-control" required>
                </div>
            </div>
            <button type="button" class="btn btn-secondary" onclick="addEducation()">Add More Education</button>
            <button type="submit" class="btn btn-primary">Submit Education</button>
        </form>

        <!-- Friends Form -->
        <form action="<?php echo e(url('/friends')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <h2>Add Friends</h2>
            <div id="friendsContainer">
                <div class="form-group">
                    <label for="friend_name">Friend Name:</label>
                    <input type="text" name="friends[0][name]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="friend_image">Friend Image:</label>
                    <input type="file" name="friends[0][image]" class="form-control" accept="image/*" required>
                </div>
            </div>
            <button type="button" class="btn btn-secondary" onclick="addFriend()">Add More Friends</button>
            <button type="submit" class="btn btn-primary">Submit Friends</button>
        </form>
    </div>

    <script>
        function addSkill() {
            const skillsContainer = document.getElementById('skillsContainer');
            const index = skillsContainer.children.length / 2; // Each skill has two inputs
            const newSkillHTML = `
                <div class="form-group">
                    <label for="skill_name">Skill Name:</label>
                    <input type="text" name="skills[${index}][name]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="skill_percentage">Skill Percentage:</label>
                    <input type="number" name="skills[${index}][percentage]" class="form-control" min="0" max="100" required>
                </div>`;
            skillsContainer.insertAdjacentHTML('beforeend', newSkillHTML);
        }

        function addExperience() {
            const experienceContainer = document.getElementById('experienceContainer');
            const index = experienceContainer.children.length / 3; // Each experience has three inputs
            const newExperienceHTML = `
                <div class="form-group">
                    <label for="experience_image">Add Image:</label>
                    <input type="file" name="experiences[${index}][image]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="experience_heading">Experience Heading:</label>
                    <input type="text" name="experiences[${index}][heading]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="experience_detail">Experience Detail:</label>
                    <textarea name="experiences[${index}][detail]" class="form-control" required></textarea>
                </div>`;
            experienceContainer.insertAdjacentHTML('beforeend', newExperienceHTML);
        }

        function addEducation() {
    const educationContainer = document.getElementById('educationContainer');
    const index = educationContainer.children.length / 5; // Each education has five inputs
    const newEducationHTML = `
        <div class="form-group">
            <label for="education_image">Add Image:</label>
            <input type="file" name="educations[${index}][image]" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="education_detail">Education Detail:</label>
            <input type="text" name="educations[${index}][detail]" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="education_year_start">Start Year:</label>
            <input type="text" name="educations[${index}][start_year]" class="form-control" required> <!-- Change here -->
        </div>
        <div class="form-group">
            <label for="education_year_end">End Year:</label>
            <input type="text" name="educations[${index}][end_year]" class="form-control" required> <!-- Change here -->
        </div>`;
    educationContainer.insertAdjacentHTML('beforeend', newEducationHTML);
}


        function addFriend() {
            const friendsContainer = document.getElementById('friendsContainer');
            const index = friendsContainer.children.length / 2; // Each friend has two inputs
            const newFriendHTML = `
                <div class="form-group">
                    <label for="friend_name">Friend Name:</label>
                    <input type="text" name="friends[${index}][name]" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="friend_image">Friend Image:</label>
                    <input type="file" name="friends[${index}][image]" class="form-control" accept="image/*" required>
                </div>`;
            friendsContainer.insertAdjacentHTML('beforeend', newFriendHTML);
        }
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Portfolios\resources\views/Portfolio.blade.php ENDPATH**/ ?>