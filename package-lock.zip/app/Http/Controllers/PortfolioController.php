<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PersonalInfo;
use App\Models\Skill;
use App\Models\Experience;
use App\Models\Education;
use App\Models\Friend;

class PortfolioController extends Controller
{
    public function storePersonalInfo(Request $request)
    {
        // Validate and save personal info
        $validatedData = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'intro_heading' => 'required|string|max:255',
            'intro_detail' => 'required|string',
            'cv' => 'nullable|file|mimes:pdf,doc,docx|max:2048',
        ]);
        
        if ($request->hasFile('cv')) {
            $filename = time() . '_' . $request->file('cv')->getClientOriginalName();
            $request->file('cv')->storeAs('cv_uploads', $filename, 'public');
            $validatedData['cv'] = 'cv_uploads/' . $filename;
        }

        $personalInfo = PersonalInfo::create($validatedData);
        return response()->json($personalInfo, 201);
    }

    public function storeSkills(Request $request)
    {
        // Validate and save skills
        $validatedData = $request->validate([
            'skills.*.name' => 'required|string|max:255',
            'skills.*.percentage' => 'required|integer|between:0,100',
        ]);
        
        foreach ($validatedData['skills'] as $skill) {
            Skill::create($skill);
        }
        
        return response()->json(['message' => 'Skills saved successfully!'], 201);
    }

    public function storeExperience(Request $request)
    {
        // Validate and save experiences
        $validatedData = $request->validate([
            'experiences.*.image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'experiences.*.heading' => 'required|string|max:255',
            'experiences.*.detail' => 'required|string',
        ]);
    
        foreach ($validatedData['experiences'] as $experience) {
            // Handle the image upload if it exists
            if (isset($experience['image']) && $request->hasFile('experiences.*.image')) {
                $filename = time() . '_' . $experience['image']->getClientOriginalName();
                $experience['image']->storeAs('experience_images', $filename, 'public');
                $experience['image'] = 'experience_images/' . $filename; // Set the path for the image
            }
    
            // Create the experience record in the database
            Experience::create($experience);
        }
    
        return response()->json(['message' => 'Experiences saved successfully!'], 201);
    }
    

    public function storeEducation(Request $request)
    {
        try {
            // Validate and save educations
            $validatedData = $request->validate([
                'educations' => 'required|array',
                'educations.*.detail' => 'required|string',
                'educations.*.start_year' => 'required|string', // This should now match
                'educations.*.end_year' => 'required|string', // This should now match
                'educations.*.image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            ]);
            
            foreach ($validatedData['educations'] as $education) {
                // Handle the image upload if it exists
                if (isset($education['image'])) {
                    $filename = time() . '_' . $education['image']->getClientOriginalName();
                    $education['image']->storeAs('education_images', $filename, 'public');
                    $education['image'] = 'education_images/' . $filename; // Set the path for the image
                }
    
                // Create the education record in the database
                Education::create($education);
            }
    
            return response()->json(['message' => 'Educations saved successfully!'], 201);
        } catch (\Exception $e) {
            return response()->json(['message' => 'Error saving educations: ' . $e->getMessage()], 500);
        }
    }
    
    

    public function storeFriends(Request $request)
    {
        // Validate and save friends
        $validatedData = $request->validate([
            'friends.*.name' => 'required|string|max:255',
            'friends.*.image' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
        ]);
        
        foreach ($validatedData['friends'] as $friend) {
            if (isset($friend['image']) && $friend['image']) {
                $filename = time() . '_' . $friend['image']->getClientOriginalName();
                $friend['image']->storeAs('friend_images', $filename, 'public');
                $friend['image'] = 'friend_images/' . $filename;
            }
            Friend::create($friend);
        }
        
        return response()->json(['message' => 'Friends saved successfully!'], 201);
    }
}
